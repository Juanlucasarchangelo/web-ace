# ACE — Atualização SaaS / credenciais sociais / Google Drive / home pública

**Atualização incremental:** este pacote contém somente arquivos novos ou alterados. Não contém `vendor`, `node_modules`, banco, `storage`, `.env`, segredos ou volumes Docker. Foi preparado sobre a base ACE Laravel 13 + os pacotes de tema e normalização de URL fornecidos anteriormente. Se você modificou esses arquivos depois, compare antes de substituir.

## O que já funciona nesta entrega

- `/` = apresentação pública ACE com Free, Cloud e Pro AI; `/login` = login existente; `/dashboard` = painel autenticado.
- Na ficha do site, aba **Loja & redes**, cartões rápidos de credenciais por serviço: usuário, copiar usuário, revelar/ocultar/copiar senha, editar ou criar. Os segredos usam a tabela `site_accesses` existente e criptografia do Eloquent. Não ficam no JSON de redes sociais nem são incluídos em listagens. A revelação continua auditada e requer owner/admin.
- Plano `free`, `cloud`, `pro` por empresa, separado dos papéis de usuário. Controles de acesso no backend para Drive, não só no frontend.
- Google Drive OAuth2 oficial, estado anti-CSRF de uso único, conta identificada, tokens criptografados no banco, renovação do token, listagem paginada, criação de pastas, upload e download de arquivos binários (limite de 10 MB nesta versão), desconexão local e logs de auditoria.
- Nginx configurado para reconsultar o DNS interno do Docker (evita 502 após troca de IP do serviço `app`).
- Testes unitários/feature novos para planos, OAuth, isolamento de empresas e proteção de tokens.

## O que ainda NÃO foi implementado

- **Cobrança**: preços da home são sugestão, não existe checkout, assinatura ou cobrança automática. Planos são habilitados pelo comando administrativo abaixo.
- **IA**: assistente, backups por IA e automação constam apenas no roadmap. O plano Pro é preparado para esses recursos, mas não executa IA nesta entrega.
- **Backup/sincronização contínua**: upload e download manuais funcionam; não há rotina automática ou restauração programada.
- **Outros provedores**: S3, OneDrive, iCloud não estão conectados neste pacote.
- **Google Picker**: não incluído; o escopo `drive.file` vê arquivos criados pelo ACE ou explicitamente concedidos a ele, NÃO todos os arquivos pessoais já existentes.
- **Registro público**: a home oferece entrada para contas existentes; cadastro automático, e-mails de convite comercial e pagamentos ficam para uma fase futura.

## Instalação sem perder dados

1. **Faça backup** da pasta do código e do banco de dados. Nunca use `docker compose down -v`.
2. Descompacte este ZIP na raiz de `web-ace`, substituindo apenas os arquivos presentes no ZIP. Preserve seu `.env`, `composer.lock`, `package-lock.json`, `storage` e volumes.
3. Dentro de `web-ace`, execute no PowerShell:

   ```powershell
   docker compose up -d --build
   docker compose exec app php artisan migrate --force
   docker compose exec app php artisan optimize:clear
   ```

   O serviço `migrate` do Compose já executa migrações durante o build, mas o comando explícito ajuda a confirmar o estado.
4. Abra `http://127.0.0.1:8088/` (home pública), `http://127.0.0.1:8088/login` (autenticação) e `/sites` (credenciais rápidas).
5. **Ative Cloud na empresa de teste** pelo slug/UUID da empresa (não é um sistema de cobrança):

   ```powershell
   docker compose exec app php artisan ace:plan SEU-SLUG cloud
   ```

   Para Pro: `ace:plan SEU-SLUG pro`. Para Free: `ace:plan SEU-SLUG free`. O slug consta no sistema/banco. Não precisa alterar senhas nem recriar empresas.

## Configurar Google Drive OAuth — uma única vez pelo administrador do SaaS

1. No **Google Cloud Console**, crie ou selecione um projeto.
2. Ative **Google Drive API** em APIs e serviços > Biblioteca.
3. Configure a **Tela de consentimento OAuth** e os usuários de teste, caso o app ainda esteja em modo de testes.
4. Crie uma credencial **ID do cliente OAuth > Aplicativo da Web**. URI de redirecionamento autorizado (para seu ACE local):

   `http://127.0.0.1:8088/cloud/google/callback`

   O valor tem que corresponder **exatamente** a `GOOGLE_DRIVE_REDIRECT_URI`, inclusive domínio/porta/protocolo. Em produção use seu domínio HTTPS e atualize ambos.
5. No `.env` já existente do ACE, acrescente, com os valores emitidos pelo Google Cloud Console:

   ```dotenv
   GOOGLE_DRIVE_CLIENT_ID=ID_DO_CLIENTE_OAUTH
   GOOGLE_DRIVE_CLIENT_SECRET=SEGREDO_DO_CLIENTE_OAUTH
   GOOGLE_DRIVE_REDIRECT_URI=http://127.0.0.1:8088/cloud/google/callback
   GOOGLE_DRIVE_SCOPE=https://www.googleapis.com/auth/drive.file
   ```

   **Não use sua senha do Gmail/Drive** nesses campos. O *Client Secret* é credencial técnica do aplicativo criada pelo Google Cloud, não a senha do usuário.
6. Atualize os contêineres para recarregar as variáveis do `.env`:

   ```powershell
   docker compose up -d --force-recreate app queue
   docker compose restart web
   ```

   O reinício de `app` usa a configuração `.env` fornecida via `env_file` no Compose. Não afeta os volumes do MySQL. O Nginx desta versão reconsulta o DNS para contêineres recriados.
7. Na área **Integrações em nuvem**, clique em **Conectar Google Drive**, faça login **na própria página do Google**, aprove o consentimento e retorne ao ACE. Uma vez conectado, será possível listar o que o aplicativo pode acessar, criar pastas, enviar e baixar arquivos.

**Permissões:** `drive.file` é a configuração mais restrita e indicada para começar. Ela não dá acesso automático a todos os documentos antigos do Google Drive. Para fazer uma integração futura que descubra e gerencie **todo o Drive existente**, use `https://www.googleapis.com/auth/drive` após avaliar privacidade, políticas e o processo de verificação/avaliação de segurança do Google. Alterar o escopo exige nova autorização e não deve ser feito automaticamente em clientes existentes.

### Documentação oficial

- https://developers.google.com/identity/protocols/oauth2/web-server
- https://developers.google.com/workspace/drive/api/guides/api-specific-auth

## Testes

Seu `phpunit.xml` já possui suites de Unit/Feature usando SQLite em memória. Execute **em uma imagem que tenha dependências de desenvolvimento** (`vendor/bin/phpunit`):

```powershell
docker compose exec app php artisan test --filter=CloudAndPlansTest
docker compose exec app php artisan test --filter=PlanFeaturesTest
docker compose exec app php artisan test
```

**Nota:** caso a imagem de produção exclua `phpunit` (instalação `--no-dev`), use o stage `composer-tools` ou um ambiente de desenvolvimento com `composer install` para executar os testes. Não rode testes destrutivos com banco de produção; o `phpunit.xml` do ACE configura SQLite em memória para testes.

Se o frontend falhar na compilação, envie o trecho do log de build; não execute comandos que apaguem o volume MySQL.

## Segurança e implantação SaaS

- Nunca armazene sua senha Google no cofre com a intenção de automatizar o OAuth. Senhas de redes sociais no cofre são apenas para referência humana; cada integração com API deve usar seu método oficial de autorização.
- Revele senhas somente sob demanda. Como o ACE é multitenant, reveja permissões de viewer/member antes de distribuir o sistema comercialmente.
- Produção: HTTPS, domínio próprio, segredos e `APP_KEY` protegidos, backups do banco, política de privacidade/LGPD, rotação de segredos, monitoramento, controle de limites e plano de restauração testado.
- Para disponibilizar OAuth a muitos clientes, publique a tela de consentimento e cumpra o processo de verificação exigido pelo Google para os escopos escolhidos.
